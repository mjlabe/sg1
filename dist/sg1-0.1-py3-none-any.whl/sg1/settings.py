import os

BASE_DIR = os.getcwd()

TEMPLATE_FOLDER = 'templates'
CONTENT_FOLDER = 'content'
OUTPUT_FOLDER = 'html'

